package com.rgbtape.app;

import com.google.firebase.firestore.FirebaseFirestore;

public class ConnectionHandler {
    private FirebaseFirestore db = FirebaseFirestore.getInstance();

}
