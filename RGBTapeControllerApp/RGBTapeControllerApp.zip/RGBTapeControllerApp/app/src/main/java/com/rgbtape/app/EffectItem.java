package com.rgbtape.app;

public class EffectItem {
    private String effectname;

    public EffectItem(String effectname){
        this.effectname = effectname;
    }

    public String getEffectname(){
        return effectname;
    }
}
