package com.rgbtape.app;

import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.pes.androidmaterialcolorpickerdialog.ColorPicker;

import java.util.ArrayList;

public class HomeFragment extends Fragment {

    private ArrayList<EffectItem> effectsList;
    private EffectsAdapter mAdapter;

    //TODO: will actually init with whatever the state of the tape is...
    private boolean on = true;

    private Colour colour;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        //init controls
        colour = new Colour(0,0,0);
        initList();
        initColourButton(view);
        initOnOff(view);
        initSlider(view);

        Spinner effectsSpinner = view.findViewById(R.id.spinner);
        mAdapter = new EffectsAdapter(getContext(), effectsList);
        effectsSpinner.setAdapter(mAdapter);
        effectsSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                EffectItem clickedItem = (EffectItem) parent.getItemAtPosition(position);
                String clickedName = clickedItem.getEffectname();

                Toast.makeText(getContext(), clickedName + " selected", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        return view;
    }

    private void initOnOff(View view){
        final ImageButton onOff = (ImageButton) view.findViewById(R.id.on_off_button);
        onOff.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if (on){
                    on = false;
                    onOff.setImageResource(R.drawable.off);
                } else {
                    on = true;
                    onOff.setImageResource(R.drawable.on);
                }
            }
        });
    }

    private void initColourButton(View view){
          Button colourButton = view.findViewById(R.id.colour_button);
        colourButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCp();
            }
        });
    }

    private void initSlider(View view){
        SeekBar seekBar = (SeekBar) view.findViewById(R.id.seekBar);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                Toast.makeText(getContext(), "Progress " + seekBar.getProgress(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showCp(){
        final ColorPicker cp = new ColorPicker(getActivity(), colour.getRed(), colour.getGreen(),colour.getBlue());
        cp.show();
        Button okButton = (Button) cp.findViewById(R.id.okColorButton);

        okButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                /* You can get single channel (value 0-255) */
                colour = new Colour(cp.getRed(), cp.getGreen(), cp.getBlue());

                /* Or the android RGB Color (see the android Color class reference) */
                setButtonColour(cp.getColor());

                cp.dismiss();
            }
        });
    }

    private void setButtonColour(int colour){
        Button colourButton = getView().findViewById(R.id.colour_button);
        colourButton.setBackgroundColor(colour);
    }

    private void initList(){
        effectsList = new ArrayList<>();
        effectsList.add(new EffectItem("Spectrum Cycling"));
        effectsList.add(new EffectItem("Breathing"));
    }
}
